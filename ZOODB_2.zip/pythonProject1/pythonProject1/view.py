import connect
from connect import connection
import sql_queries

try:
    with connection.cursor() as cursor:
        cursor.execute(sql_queries.view_List_of_pets_by_category)
        view1 = cursor.fetchall()
        print("Список животных по категориям:")
        for i in view1:
            print(f"Категория: {i['category']}, | кличка: {i['nickname']}, | возраст: {i['age']} , | Порода: {i['breed']}, | цена: {i['price']} ")

        print("_" * 20)
        cursor.execute(sql_queries.view_List_of_receipts_and_customers)
        view2 = cursor.fetchall()
        print("Продажи:")
        for y in view2:
            print(
                f"Дата: {y['date']}, | Способ оплаты: {y['payment_type']}, | Имя: {y['first_name']},| Фамилия: {y['last_name']},| Телефон: {y['phone']} ")

            print("_" * 20)

        cursor.execute(sql_queries.view_The_most_expensive_pet)
        view3 = cursor.fetchall()
        print("Самые дороги:")
        for e in view3:
            print(f"Кличка: {e['nickname']}, | Порода: {e['breed']}, | Цена: {e['price']} ")

            print("_" * 20)

        cursor.execute(sql_queries.view_Category_with_the_most_pets)
        view4 = cursor.fetchall()
        print("Больше всего питомцев:")
        for u in view4:
            print(f"Количество животных : {u['num_pets']}, | Категории : {u['category']}")


finally:
    connection.close()

