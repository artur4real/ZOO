import re
from connect import connection
try:
    with connection.cursor() as cursor:
        while True:

            DB = input("Авторизация (1), регистрация (2): ")
            if DB == "1":
                login = input("Введите логин\email: ")
                password = input("Введите пароль: ")
                user_avtorization = f"select email, login, password from Customer " \
                               f"where (email = '{login}' and password = '{password}')  " \
                               f"or login = '{login}' and password = '{password}'"
                cursor.execute(user_avtorization)
                user_avtorization = cursor.fetchall()
                if user_avtorization:
                    print("Вход выполнен успешно!")
                    break

                else:
                    print("Неверный логин или пароль")

            elif DB == "2":
                print("Регистрация: ")
                namereg = input("Введите имя:")
                familreg = input("Введите фамилию:")
                phonereg = input("Введите телефон:")
                loginreg = input("Введите логин:")
                while True:
                    passreg = input("Введите пароль: ")
                    if re.search("[@_!#$%^&*()<>?/\|}{~:]", passreg):
                        break
                    else:
                        print("Пароль должен содержать хотя бы один специальный символ: @, _, !, #, $, %, ^, &, *, (, ), <, >, ?, /, \, |, {, }, ~, :")
                emailreg = input("Введите email: ")
                paspreg = input()
                user_reg = f"insert into Customer(first_name,last_name,email,phone,login,password, passport) values " \
                                    f"('{namereg}','{familreg}','{emailreg}','{phonereg}','{loginreg}',PASSWORD('{passreg}'),'{paspreg}')"
                cursor.execute(user_reg)
                user_reg = cursor.fetchall()
                connection.commit()
                if user_reg:
                    print("Регестрация выполнен успешно!")
                    break
finally:
    connection.close()











