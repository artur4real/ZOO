from connect import connection
import sql_queries
# Обработка исключений
try:
        with connection.cursor() as cursor:
            #создание таблицы Categ
            cursor.execute(sql_queries.create_table_categ)
            connection.commit()
            #создание таблицы pets
            cursor.execute(sql_queries.create_table_pets)
            connection.commit()
            #создание таблицы custom
            cursor.execute(sql_queries.create_table_custom)
            connection.commit()
            #создание таблицы basket
            cursor.execute(sql_queries.create_table_basket)
            connection.commit()
            #создание таблицы cheque
            cursor.execute(sql_queries.create_table_cheque)
            connection.commit()
            #создание таблицы sales
            cursor.execute(sql_queries.create_table_sales)
            connection.commit()
            #ввод данных category
            cursor.execute(sql_queries.insert_category)
            connection.commit()
            # ввод данных pets
            cursor.execute(sql_queries.insert_pets)
            connection.commit()
            #ввод данных c Customers
            cursor.execute(sql_queries.insert_Customer)
            connection.commit()
            # создание таблицы Categ
            cursor.execute(sql_queries.insert_Basket)
            connection.commit()
            # создание таблицы Categ
            cursor.execute(sql_queries.insert_Cheque)
            connection.commit()
            # создание таблицы Categ
            cursor.execute(sql_queries.insert_Sales)
            connection.commit()

finally:
    connection.close()
