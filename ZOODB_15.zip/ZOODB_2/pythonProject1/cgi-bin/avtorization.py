import validatin

from connect import connection
getback = True
try:
    with connection.cursor() as cursor:
        while True:
            avtorization_regestration = input("Авторизация (1), Регестрация (2): ")
            if avtorization_regestration == "1":

                    login = input("Введите логин\email: ")
                    password = input("Введите пароль: ")
                    user_avtorization = f"SELECT id  FROM customer " \
                                        f"WHERE (login = '{login}' AND password = PASSWORD('{password}')) " \
                                        f"OR (email = '{login}' AND password = PASSWORD('{password}'))"
                    cursor.execute(user_avtorization)
                    user_avtorization = cursor.fetchall()
                    id_cust = user_avtorization[0]['id']
                    if user_avtorization:
                        id_cust = int(user_avtorization[0]['id'])
                        print("Вы вошли в личный кабинет!")
                        cursor.execute("select * from category_pets_view")
                        pets_by_category_query = cursor.fetchall()
                        print("Список животных по категориям:")
                        print(pets_by_category_query)
                        for i in pets_by_category_query:
                            print(
                                f"Категория: {i['name']}, | кличка: {i['nickname']}, | возраст: {i['age']}, |  цена: {i['price']}")

                        buy = input("Хотите купить животное? (введите да или нет):")
                        if buy.lower() == "да":
                            nick = input("Кличка понравившегося питомца:")
                            hp_basket = f"CALL hp_basket('{nick}', '{id_cust}')"
                            cursor.execute(hp_basket)
                            connection.commit()
                        else:
                            print("До свидания!")
                    else:
                        print("Неверный логин или пароль")

            elif avtorization_regestration == "2":
                while getback:
                    print("Регистрация: ")
                    Name = input("Введите имя -> ")
                    surname = input("Введите фамилию -> ")
                    while True:
                        phonereg = input("Введите телефон ->")
                        if validatin.is_valid_phone_number(phonereg):
                            print('Номер телефона валидный.')
                            break
                        else:
                            print('Номер телефона должен начинатся с +')
                            continue
                    loginret = True
                    while loginret:
                        loginreg = input("Введите логин -> ")
                        if len(loginreg) < 4 or len(loginreg) > 10:
                            False, print("Логин должен содержать от 4 до 10 символов")
                        else:
                            loginret = False
                            break
                    while True:
                        passreg = input('Введите пароль -> ')
                        if validatin.is_valid_password(passreg):
                            print('Пароль надежный.')
                            break
                        else:
                            print('Пароль ненадежный! ')
                            continue
                    while True:
                        emailreg = input("Введите email -> ")
                        if validatin.is_valid_email(emailreg):
                            print('Email валидный.')
                            break
                        else:
                            print('Email невалидный!')
                            continue
                    pasportreg = input("Введите паспорт ->")
                    user_reg = f"insert into Customer(first_name,last_name,email,phone,login,password, passport) values " \
                               f"('{Name}','{surname}','{emailreg}','{phonereg}','{loginreg}',PASSWORD('{passreg}'),'{pasportreg}')"
                    cursor.execute(user_reg)
                    user_reg = cursor.fetchall()
                    connection.commit()
                    print("Регистрация прошла успешно. Переход на страницу авторизации...")
                    getback = False
finally:
    connection.close()
